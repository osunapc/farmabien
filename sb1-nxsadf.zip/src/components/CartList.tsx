import { useCartStore } from '../store/cartStore';

export default function CartList() {
  const { items, removeItem, updateQuantity, total } = useCartStore();

  if (items.length === 0) {
    return (
      <div class="text-center py-8">
        <p class="text-gray-600">Tu carrito está vacío</p>
        <a href="/productos" class="text-primary hover:underline mt-4 inline-block">
          Ver productos
        </a>
      </div>
    );
  }

  return (
    <div>
      {items.map((item) => (
        <div key={item.id} class="flex items-center gap-4 border-b py-4">
          <img
            src={item.image}
            alt={item.name}
            class="w-24 h-24 object-cover rounded"
          />
          <div class="flex-grow">
            <h3 class="font-bold">{item.name}</h3>
            <p class="text-primary">S/ {item.price.toFixed(2)}</p>
            <div class="flex items-center gap-2 mt-2">
              <label>Cantidad:</label>
              <select
                value={item.quantity}
                onChange={(e) => updateQuantity(item.id, parseInt(e.target.value))}
                class="border rounded px-2 py-1"
              >
                {[1, 2, 3, 4, 5].map((num) => (
                  <option key={num} value={num}>
                    {num}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <button
            onClick={() => removeItem(item.id)}
            class="text-red-500 hover:text-red-700"
          >
            Eliminar
          </button>
        </div>
      ))}
      
      <div class="mt-4 text-right">
        <p class="text-xl font-bold">
          Total: S/ {total().toFixed(2)}
        </p>
      </div>
    </div>
  );
}