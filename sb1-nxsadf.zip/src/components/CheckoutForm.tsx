import { useState } from 'react';
import { useCartStore } from '../store/cartStore';
import { supabase } from '../lib/supabase';

export default function CheckoutForm() {
  const { total, items, clearCart } = useCartStore();
  const [paymentImage, setPaymentImage] = useState<File | null>(null);
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (items.length === 0) {
      alert('Tu carrito está vacío');
      return;
    }

    if (!paymentImage) {
      alert('Por favor sube el comprobante de pago');
      return;
    }

    setLoading(true);

    try {
      const user = await supabase.auth.getUser();
      
      if (!user.data.user) {
        alert('Debes iniciar sesión para realizar un pedido');
        return;
      }

      // Subir imagen del comprobante
      const { data: imageData, error: imageError } = await supabase.storage
        .from('payment-proofs')
        .upload(`${user.data.user.id}/${Date.now()}-${paymentImage.name}`, paymentImage);

      if (imageError) throw imageError;

      // Crear el pedido
      const { data: orderData, error: orderError } = await supabase
        .from('orders')
        .insert([{
          user_id: user.data.user.id,
          items,
          total: total(),
          payment_proof_url: imageData.path,
          phone,
          status: 'pending',
          created_at: new Date().toISOString()
        }])
        .select()
        .single();

      if (orderError) throw orderError;

      alert('¡Pedido realizado con éxito!');
      clearCart();
      window.location.href = '/pedidos';
    } catch (error) {
      console.error('Error al procesar el pedido:', error);
      alert('Error al procesar el pedido');
    } finally {
      setLoading(false);
    }
  };

  const deliveryCost = total() >= 100 ? 0 : 10;
  const finalTotal = total() + deliveryCost;

  return (
    <div class="bg-white p-6 rounded-lg shadow-md">
      <h2 class="text-xl font-bold mb-4">Resumen del Pedido</h2>
      
      <div class="mb-6">
        <p class="flex justify-between mb-2">
          <span>Subtotal:</span>
          <span>S/ {total().toFixed(2)}</span>
        </p>
        <p class="flex justify-between mb-2">
          <span>Delivery:</span>
          <span>{deliveryCost === 0 ? 'Gratis' : `S/ ${deliveryCost.toFixed(2)}`}</span>
        </p>
        <p class="flex justify-between font-bold text-lg">
          <span>Total:</span>
          <span>S/ {finalTotal.toFixed(2)}</span>
        </p>
      </div>

      <div class="mb-6">
        <h3 class="font-bold mb-2">Instrucciones de Pago</h3>
        <p class="text-sm text-gray-600 mb-2">Realiza el pago a través de:</p>
        <ul class="text-sm text-gray-600 list-disc list-inside mb-4">
          <li>Yape: 999-999-999</li>
          <li>Plin: 999-999-999</li>
          <li>BCP: 123-456-789</li>
        </ul>
      </div>

      <form onSubmit={handleSubmit} class="space-y-4">
        <div>
          <label class="block text-sm font-medium mb-1">Teléfono de contacto</label>
          <input
            type="tel"
            required
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            class="w-full border rounded-lg px-3 py-2"
            placeholder="Ejemplo: 999888777"
          />
        </div>

        <div>
          <label class="block text-sm font-medium mb-1">Comprobante de pago</label>
          <input
            type="file"
            required
            accept="image/*"
            onChange={(e) => setPaymentImage(e.target.files?.[0] || null)}
            class="w-full border rounded-lg px-3 py-2"
          />
        </div>

        <button
          type="submit"
          disabled={loading}
          class="w-full bg-primary hover:bg-primary/90 disabled:bg-gray-400 text-white font-bold py-3 px-6 rounded-lg transition-colors"
        >
          {loading ? 'Procesando...' : 'Confirmar Pedido'}
        </button>
      </form>
    </div>
  );
}